var config = {
    map: {
        '*': {
            colorpicker:       'jquery/colorpicker/js/colorpicker',
        }
    },
};
